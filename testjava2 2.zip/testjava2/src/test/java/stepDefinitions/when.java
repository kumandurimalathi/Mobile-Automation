package stepDefinitions;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import config.AndroidBaseClass;
import config.baseclass;
import cucumber.api.PendingException;
import cucumber.api.java.en.When;
import helpers.mobileactions;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import utils.genericutilities;

public class when extends baseclass {
	private String platform;
	private Properties androidprop, dataprop;
	mobileactions androidactions;
	genericutilities utils;

	AndroidBaseClass android = new AndroidBaseClass(androiddriver);

	public when() throws IOException {
		platform = "android";
		androiddriver = android.callDriver();
		FileInputStream reader = new FileInputStream(
				System.getProperty("user.dir") + "/src/main/testdata/android.properties");
		androidprop = new Properties();
		androidprop.load(reader);
		FileInputStream dataread = new FileInputStream(
				System.getProperty("user.dir") + "/src/main/testdata/data.properties");
		dataprop = new Properties();
		dataprop.load(dataread);

		androidactions = new mobileactions(androiddriver);
		utils = new genericutilities();
	}

	@When("^I clear \"([^\"]*)\" (?:textbox|field)$")
	public void i_clear_field(String object) throws Throwable {
		switch (platform) {
		case "android":
			MobileElement el = driver.findElementByXPath(androidprop.getProperty(object));
			String Data = el.getText();
			el.clear();
			System.out.println(Data + " is cleared");
			androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I tap on \"([^\"]*)\" (?:|button|label|card|link|icon|option|field|mark)$")
	public void i_tap_on_icon(String object) throws Throwable {
		switch (platform) {
		case "android":
			driver.findElementByXPath(androidprop.getProperty(object)).click();
			System.out.println(object + " is clicked");
			androidactions.takescreenshot(feature);

			break;
		}
	}

	@When("^I tap \"([^\"]*)\" (?:|button|link|header|field|tab|option|view|checkbox)$")
	public void i_tap_button(String object) throws Throwable {
		switch (platform) {
		case "android":
			driver.findElementByXPath(androidprop.getProperty(object)).click();
			System.out.println(object + " is clicked");
			androidactions.takescreenshot(feature);
			break;
		}
	}
	

	@When("^I tap \"([^\"]*)\"$")
	public void i_tap(String object) throws Throwable {
		switch (platform) {
		case "android":
			androiddriver.findElementByXPath(androidprop.getProperty(object)).click();
			System.out.println(object + " is clicked");
        androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I tap \"([^\"]*)\" (?:view|checkbox)$")
	public void i_tap_checkbox(String object) throws Throwable {
		switch (platform) {
		case "android":
			androiddriver.findElementByXPath(androidprop.getProperty(object)).click();
			System.out.println(object + " is clicked");
        androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I enter \"([^\"]*)\" into \"([^\"]*)\" field$")
	public void i_enter_into_field(String value, String object) throws Throwable {
		try {
			switch (platform) {
			case "android":
				boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
				if (exists) {
					String val = dataprop.getProperty(value);
					driver.findElementByXPath(androidprop.getProperty(object)).click();
					driver.findElementByXPath(androidprop.getProperty(object)).clear();
					driver.findElementByXPath(androidprop.getProperty(object)).sendKeys(val);
					androidactions.hideDeviceKeyboard();
					System.out.println("Entered " + val + " in " + object + " field");
				}
				androidactions.takescreenshot(feature);

				break;
			}
		} catch (Exception e) {
			System.out.println("cannot Enter data" + e);
			throw new Exception(e);
		}
	}

	@When("^I select \"([^\"]*)\"$")
	public void i_select(String object) throws Throwable {
		switch (platform) {
		case "android":
			if (object.equals("year")) {
				int year = Integer.parseInt(dataprop.getProperty("year"));

				String Data = utils.getCurrentYear();
				int year1 = Integer.parseInt(Data);
				while (year1 >= year) {
					year1 = year1 - 4;
					androidactions.swipeTillText(Integer.toString(year1));
				}
				MobileElement element1 = androiddriver.findElementByAndroidUIAutomator(

						"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
								+ Integer.toString(year) + "\").instance(0))");
				element1.click();
			} else if (object.equals("month")) {

				MobileElement el123 = (MobileElement) androiddriver
						.findElementByXPath(androidprop.getProperty("previous.month"));
				MobileElement el13 = (MobileElement) androiddriver.findElementByXPath(androidprop.getProperty("month.text"));


				String Data = el13.getAttribute("contentDescription");
				while (!Data.contains(dataprop.getProperty("month"))) {
					el123.click();

					MobileElement el113 = (MobileElement) androiddriver

							.findElementByXPath(androidprop.getProperty("month.text"));

					Data = el113.getAttribute("contentDescription");
				}
			} else if (object.equals("date")) {

				MobileElement el13 = (MobileElement) driver
						.findElementByXPath("//android.view.View[@text='" + dataprop.getProperty(object) + "']");
				el13.click();
			}
			androidactions.takescreenshot(feature);
			break;

		}
	}

	@When("^I tap on \"([^\"]*)\"$")
	public void i_tap_on(String object) throws Throwable {
		switch (platform) {
		case "android":
			driver.findElementByXPath(androidprop.getProperty(object)).click();
			System.out.println(object + " is clicked");
			androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I Swipe Down \"([^\"]*)\"$")
	public void i_Swipe_Down(String object) throws Throwable {
		androidactions.swipeDownTillElement(androidprop.getProperty(object));
		System.out.println(object + " found");
		androidactions.takescreenshot(feature);
		
	}

	@When("^I Swipe Down till \"([^\"]*)\"$")
	public void i_Swipe_Down_till(String object) throws Throwable {
		androidactions.swipeDownTillElement(androidprop.getProperty(object));
		System.out.println(object + " found");
		androidactions.takescreenshot(feature);
	}

	@When("^I Swipe Down till \"([^\"]*)\" in \"([^\"]*)\"$")
	public void i_Swipe_Down_till_in_field(String object, String value) throws Throwable {
		androidactions.swipeDownTillElement(androidprop.getProperty(object));
		System.out.println(object + " found in " + value);
		androidactions.takescreenshot(feature);
	}

	

		

	

	@When("^I select \"([^\"]*)\" in \"([^\"]*)\" (?:field|List)$")
	public void i_select_in_field(String value, String object) throws Throwable {
		String data = dataprop.getProperty(value);
		switch (platform) {

		case "android":
			if (object.equals("year")) {

				int year = Integer.parseInt(data);
				String Data = utils.getCurrentYear();
				int year1 = Integer.parseInt(Data);
				while (year1 >= year) {
					year1 = year1 - 5;
					androidactions.swipeTillText(Integer.toString(year1));

					// element.click();
					// el10.click();
				}
				MobileElement element1 = androiddriver.findElementByAndroidUIAutomator(

						"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
								+ Integer.toString(year) + "\").instance(0))");
				element1.click();
			} else if (object.equals("year.of.birth")) {
				System.out.println(object);
				int year = Integer.parseInt(data);
				String Data1 = driver.findElementByXPath(androidprop.getProperty(object)).getText();
				System.out.println(Data1);
				int year1 = Integer.parseInt(Data1);

				if ((year1 >= year)) {
					while (year1 >= year) {
						year1 = year1 - 4;
						System.out.println(year1 + " " + year);
						androidactions.swipeTillText(Integer.toString(year1));
//					driver.findElementByXPath(androidprop.getProperty("year")).click();
					}
					MobileElement element1 = driver.findElementByAndroidUIAutomator(
							"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
									+ Integer.toString(year) + "\").instance(0))");
					element1.click();
					// driver.findElementByXPath(androidprop.getProperty("year")).click();
				} else {
					while (year1 <= year) {
						year1 = year1 + 4;
						System.out.println(year1 + " " + year);
						androidactions.swipeTillText(Integer.toString(year1));
						MobileElement element1 = driver.findElementByAndroidUIAutomator(
								"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
										+ Integer.toString(year1) + "\").instance(0))");
						element1.click();
						driver.findElementByXPath(androidprop.getProperty("year")).click();
						// break;
					}
					MobileElement element1 = driver.findElementByAndroidUIAutomator(
							"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
									+ Integer.toString(year) + "\").instance(0))");
					element1.click();

					// break;
				}

			} else if (object.equals("month")) {
				MobileElement el123 = (MobileElement) driver
						.findElementByXPath(androidprop.getProperty("previous.month"));
				MobileElement el13 = (MobileElement) driver.findElementByXPath(androidprop.getProperty("month.text"));

				String Data = el13.getAttribute("contentDescription");
				while (!Data.contains(dataprop.getProperty(value))) {
					el123.click();
					MobileElement el113 = (MobileElement) driver
							.findElementByXPath(androidprop.getProperty("month.text"));

					Data = el113.getAttribute("contentDescription");
				}
			} else if (object.equals("date")) {
				MobileElement el13 = (MobileElement) driver
						.findElementByXPath("//android.view.View[@text='" + dataprop.getProperty(value) + "']");
				el13.click();
			} else if (object.equals("hour")) {
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				String hourdata = androidprop.getProperty(object).replace("9", data);
				driver.findElementByXPath(hourdata).click();
			} else if (object.equals("minutes")) {
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				String mindata = androidprop.getProperty(object).replace("05", data);
				driver.findElementByXPath(mindata).click();
			} else if (object.equals("am")) {
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				driver.findElementByXPath(androidprop.getProperty(object)).click();
			} else if (object.equals("pm")) {
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				driver.findElementByXPath(androidprop.getProperty(object)).click();
			} else {
				System.out.println(object + "not founds");
			}
			androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I tap outside \"([^\"]*)\" field$")
	public void i_tap_outside_field(String object) throws Throwable {
		switch (platform) {

		case "android":

			androidactions.tapOutsideElement();

			androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I hide device keyboard$")
	public void i_hide_device_keyboard() throws Throwable {
		switch (platform) {

		case "android":
			androidactions.hideDeviceKeyboard();
			androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I swipe left \"([^\"]*)\" screen$")
	public void i_swipe_left_screen(String object) throws Throwable {
		switch (platform) {
		case "android":
			androidactions.swipeLeft(0.8);
			System.out.println(object + " found");
			androidactions.takescreenshot(feature);
			break;
		}

	}

	@When("^I swipe right \"([^\"]*)\" screen$")
	public void i_swipe_right_screen(String object) throws Throwable {
		switch (platform) {
		case "android":
			androidactions.swipeRight(0.8);
			System.out.println(object + " found");
			androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I swipe down$")
	public void i_swipe_down() throws Throwable {
		switch (platform) {
		case "android":
			androidactions.swipeDown(0.8);
			System.out.println(" found");
			androidactions.takescreenshot(feature);
			break;
		}
	}

	@When("^I wait for \"([^\"]*)\" minutes$")
	public void i_wait_for_minutes(int value) throws Throwable {
		try {
		int val = parseInt(value);
		int val1 = val * 60 * 100;
		driver.wait(val1);
		System.out.println("Wait");

		androidactions.takescreenshot(feature);
	} catch(Exception e) {
		System.out.println("Cannot Wait");
	}
	}
	private int parseInt(int val) {
		// TODO Auto-generated method stub
		return 0;
	}

	@When("^I relaunch the app again$")
	public void i_relaunch_the_app_again() throws Throwable {
		switch (platform) {
		case "android":
		 driver.launchApp();
		 System.out.println("Application is launched");

			androidactions.takescreenshot(feature);
			break;
	}
}
	@When("^I login multiple times$")
	public void i_login_multiple_times() throws Throwable {
		switch (platform) {
		case "android":
			boolean exists = driver.findElementByXPath(androidprop.getProperty("login")).isDisplayed();
			for (int i = 0; i < 50; i++) {
				 driver.findElementByXPath(androidprop.getProperty("login")).click();
					System.out.println(" Clicked on Login"  +i+  "time");
					try { 
						if (androidactions.waitForVisibility(androidprop.getProperty("account.locked"))) {
							driver.findElementByXPath(androidprop.getProperty("okay.button")).click();
							System.out.println(" Clicked on ok");
							break;
							}
					} catch (Exception e) {
						if(androidactions.waitForVisibility(androidprop.getProperty("incorrect.username"))) {
						 driver.findElementByXPath(androidprop.getProperty("okay.button")).click();
						 System.out.println(" Clicked on okay"  +i+  "time");
						}
					}
					
				}
			androidactions.takescreenshot(feature);
break;
			}

		}
	


	@When("^I enable remember me toggle button$")
	public void i_enable_remember_me_toggle_button() throws Throwable {
		switch (platform) {
		case "android":
			MobileElement el = driver.findElementByXPath(androidprop.getProperty("remember.me.toggle.off"));
			el.isDisplayed();
			el.click();	
			androidactions.takescreenshot(feature);
			break;
		}
	}

	
	@When("^I disable remember me toggle button$")
	public void i_disable_remember_me_toggle_button() throws Throwable {
		switch (platform) {
		case "android":
			MobileElement el = driver.findElementByXPath(androidprop.getProperty("remember.me.toggle.on"));
			el.isDisplayed();
			el.click();
			androidactions.takescreenshot(feature);	
			break;
		}

	}
	@When("^I should see \"([^\"]*)\" (?:accepted|unaccepted) in \"([^\"]*)\" field$")
	public void i_should_see_accepted_or_unaccepcted_in_field(String value, String object) throws Throwable {
		
		switch(platform){
		case "android":
			boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
			
			if(exists) {
				String val = dataprop.getProperty(value);
				String accepctedtext = driver.findElementByXPath(androidprop.getProperty(object)).getText();
		
				String enteredtext = dataprop.getProperty(value);
				
				if(enteredtext.equals(accepctedtext)) {
					System.out.println("Accepcted Text: " + accepctedtext);
					System.out.println("Entered Text: "+enteredtext);
					System.out.println("Text is accepcted");
				}
				else {
					System.out.println("Accepcted Text: " + accepctedtext);
					System.out.println("Entered Text: "+enteredtext);
					System.out.println("Text is not accepcted");
				}
		   
			}

			androidactions.takescreenshot(feature);
			break;
		}
	   
	}
	

	@When("^I choose \"([^\"]*)\" option in \"([^\"]*)\"$")
	public void i_choose_option_as(String value, String object) throws Throwable {
		try {
			String[] array = { "At the time of event", "5 minutes before", "15 minutes before", "30 minutes before",
					"1 hour before", "2 hours before", "None" };
			boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
			List<MobileElement> list = androiddriver.findElements(By.xpath(androidprop.getProperty(object)));
			int index;
			// System.out.println(list.size());
			for (index = 0; index < list.size(); index++) {
				// System.out.println(array[index]+" "+dataprop.getProperty(value));
				if (array[index].equals(dataprop.getProperty(value))) {
					// System.out.println(array[index]);
					list.get(index).click();
				}
			}
			System.out.println(value + " is selected in " + object);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	
}
