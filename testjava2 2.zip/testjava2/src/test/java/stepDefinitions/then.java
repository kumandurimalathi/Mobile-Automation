package stepDefinitions;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

//import javax.mail.internet.ParseException;

import org.apache.commons.validator.routines.DateValidator;
import org.testng.annotations.Test;

import config.AndroidBaseClass;
import config.baseclass;
import config.iOSBaseClass;
import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import helpers.mobileactions;
import io.appium.java_client.MobileElement;

public class then extends baseclass{
	private String platform,deviceName;
	private Properties androidprop,androidText,dataprop;

	mobileactions androidactions;

	AndroidBaseClass android = new AndroidBaseClass(androiddriver);
	iOSBaseClass ios = new iOSBaseClass(iosdriver);
	public then() throws IOException {
		platform = "android";
		driver=android.callDriver();
		FileInputStream reader= new FileInputStream(System.getProperty("user.dir")+"/src/main/testdata/android.properties");
		FileInputStream textReader= new FileInputStream(System.getProperty("user.dir")+"/src/main/testdata/android_text.properties");
		FileInputStream dataread= new FileInputStream(System.getProperty("user.dir")+"/src/main/testdata/data.properties");

//		iosdriver = ios.callDriver();
//		FileInputStream reader = new FileInputStream(
//				System.getProperty("user.dir") + "/src/main/testdata/android.properties");
//		FileInputStream textReader = new FileInputStream(
//				System.getProperty("user.dir") + "/src/main/testdata/android_text.properties");

		androidprop = new Properties();
		androidText = new Properties();
		androidprop.load(reader);
		androidText.load(textReader);

	
		androidactions = new mobileactions(iosdriver);
//		FileInputStream dataread = new FileInputStream(
//				System.getProperty("user.dir") + "/src/main/testdata/data.properties");
		dataprop = new Properties();
		dataprop.load(dataread);
	}

	@Then("^I should see \"([^\"]*)\" (?:screen|button|view|header|subheader|label|menu|icon|dot|section|alert|card|option|title|bullet|pop-up|link|field)$")

	public void i_should_see(String object) throws Throwable {
		switch (platform) {
		case "android":
		boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
		if(exists == true) {
			System.out.println(object + " is displayed");
			
		}
		else {
			System.out.println(object + " is not displayed");
		}
		androidactions.takescreenshot(feature);
		break;

		}
	}

	@Then("^I should see \"([^\"]*)\" button is (?:enabled|disabled)$")
	public void i_should_see_button_is_enabled(String object) throws Throwable {
	    
		switch(platform){
		case "android":
			
		boolean enabled = driver.findElementByXPath(androidprop.getProperty(object)).isEnabled();
		if(enabled == true) {
			System.out.println(object + " is enabled");
		}
		else {
			System.out.println(object + " is disabled");
		}
		androidactions.takescreenshot(feature);
		break;
		}
		
	

	}

	@Then("^I Verify \"([^\"]*)\" text$")
	public void i_Verify_text(String object) throws Throwable {
		switch (platform) {
		case "android":
			boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
			if (exists) {
				String actualtext = androiddriver.findElementByXPath(androidprop.getProperty(object)).getText();
				String expectedtext = androidText.getProperty(object);
				if (expectedtext.equals(actualtext)) {
					System.out.println("Actual Text: " + actualtext);
					System.out.println("Expected Text: " + expectedtext);
					System.out.println("Text is matched");
				} else {
					System.out.println("Actual Text: " + actualtext);
					System.out.println("Expected Text: " + expectedtext);
					System.out.println("Text is not matched");
				}

			}
			break;
		}
	}

	@Then("^I should see \"([^\"]*)\"$")
	public void i_should_see_(String object) throws Throwable {
		switch (platform) {
		case "android":
			boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
			if (exists) {
				System.out.println(object + " is displayed");
			}
			break;
		}
	}

	@Then("^I should see \"([^\"]*)\" text$")
	public void i_should_see_text(String object) throws Throwable {
		switch (platform) {
		case "android":
			boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
			if (exists) {
				String actual = androiddriver.findElementByXPath(androidprop.getProperty(object)).getText();

				System.out.println(object + " is displayed");
				System.out.println("Text Displayed is : " + actual);
			}
			break;
		}
		androidactions.takescreenshot(feature);
		
		}
	

	
	
	
	
	
	@Then("^I should (?:not see|see) \"([^\"]*)\" in \"([^\"]*)\" field$")
	public void i_should_see_not_see_in_field(String value, String object) throws Throwable {
		switch(platform){
		case "android":
		
			
		boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
		
		if(exists) {
			String val = dataprop.getProperty(value);
			String actualtext = driver.findElementByXPath(androidprop.getProperty(object)).getText();
			String expectedtext = dataprop.getProperty(value);
			if(expectedtext.equals(actualtext)) {
				System.out.println(actualtext+" is displayed in "+object);
			}
			else {
				System.out.println(actualtext+" is not displayed in "+object);
			}
			
			
		}
		androidactions.takescreenshot(feature);
		break;
			}
	}
	@Then("^I should see \"([^\"]*)\" (?:selected|Deselected)$")
	public void i_should_see_selected(String object) throws Throwable {
		switch(platform){
		case "android":
		boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
		if(exists) {
			String checked = driver.findElementByXPath(androidprop.getProperty(object)).getAttribute("checked");
					
			
			if(checked.equals("true")) {
				System.out.println(object+" is selected");
			}
			else {
				System.out.println(object+" is not selected");
			}
			
			
		}
		androidactions.takescreenshot(feature);
		break;
		}
	}
	
	
	
	
	@Then("^I should see \"([^\"]*)\" in MM-DD-YYYY format$")
	public void i_should_see_in_MM_DD_YYYY_format(String object) throws Throwable {
		switch(platform){
		case "android":
			boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
			
			if(exists) {
				String format = driver.findElementByXPath(androidprop.getProperty(object)).getText();
				//SimpleDateFormat date = new SimpleDateFormat("MM/dd/yyyy");
				mobileactions.validateJavaDate(format);
				System.out.println("format " + format);
			
		  }
			androidactions.takescreenshot(feature);
			break;
		}
	
}
	
	@Then("^I should see the \"([^\"]*)\"$")
	public void i_should_see_the(String object) throws Throwable {
		switch(platform){
		case "android":
		boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
		if(exists) {
			System.out.println(object + " is displayed");
		}
		androidactions.takescreenshot(feature);
		break;
		} 
	}
	
	
	@Then("^I should see empty \"([^\"]*)\" field$")
	public void i_should_see_empty_field(String object) throws Throwable {
		switch(platform){
		case "android":
		boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
		if(exists) {
			  if (object.equals("edit.screen.first.name")) {
				  String fieldName = dataprop.getProperty(object);
				  
				  String emptyfieldtext = driver.findElementByXPath(androidprop.getProperty(object)).getAttribute("text"); 
				  System.out.println(" Text: " + emptyfieldtext);
				  if(emptyfieldtext.equals(fieldName)) {
						System.out.println(object + " is empty");
						
					}
				  else {
			  
					  	System.out.println(object + " is not empty");
				  	}
			  }
			  
			  else if (object.equals("edit.screen.last.name")) {
				  String fieldName1 = dataprop.getProperty(object);
				  String emptyfieldtext1 = driver.findElementByXPath(androidprop.getProperty(object)).getAttribute("text"); 
				  System.out.println(" Text: " + emptyfieldtext1);
				  if(emptyfieldtext1.equals(fieldName1)) {
						System.out.println(object + " is empty");
						
					}
				  else {
			  
					  	System.out.println(object + " is not empty");
				  	}
			  }
			  
			  
			  
		}
		androidactions.takescreenshot(feature);
		break;
	} 
}
	
	
	
	@Then("^I should see \"([^\"]*)\" and \"([^\"]*)\" in \"([^\"]*)\"$")
	public void i_should_see_and_in(String value1, String value2, String object) throws Throwable {
		switch(platform){
		case "android":
			
		boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
		if(exists) {
			
			String value1data = dataprop.getProperty(value1);
			String value2data = dataprop.getProperty(value2);
			 String fieldtext = driver.findElementByXPath(androidprop.getProperty(object)).getText(); 
			 String valuedata = value1data + " " + value2data;
			 System.out.println(valuedata);
			 if(valuedata.equals(fieldtext)) {
					System.out.println(fieldtext + "value displayed is matched");
					
				}
			 else {
				 System.out.println(fieldtext + "value displayed is not matched");
		}
	    
	}
		androidactions.takescreenshot(feature);
		break;
	}
}

	@Then("^I should see \"([^\"]*)\" link is enabled$")
	public void i_should_see_link_is_enabled(String object) throws Throwable {
	switch(platform){
	case "android":
	boolean exists = driver.findElementByXPath(androidprop.getProperty(object)).isEnabled();
	if(exists) 
	{
	System.out.println(object + " is enabled");
	}
	else 
	{
		System.out.println(object + " is disabled");
	}
	androidactions.takescreenshot(feature);
	break;
	}
	}
	
	@Then("^\"([^\"]*)\" link should be enabled$")
	public void link_should_be_enabled(String object) throws Throwable {
		switch(platform){
		case "android":
		boolean exists = driver.findElementByXPath(androidprop.getProperty(object)).isEnabled();
		if(exists) 
		{
		System.out.println(object + " is enabled");
		}
		else 
		{
			System.out.println(object + " is disabled");
		}
		androidactions.takescreenshot(feature);
		break;
		}
	}

	@Then("^I should see remember me toggle button is disabled$")
	public void i_should_see_remember_me_toggle_button_is_disabled() throws Throwable {
		switch(platform){
		case "android": 
//			switch (deviceName) {
//			case "samsungS9":
//				
//				boolean exists = driver.findElementByXPath(androidprop.getProperty("samsungs9.remember.me.toggle.off")).isEnabled();
//				if(exists == true) {
//					System.out.println("remember.me.toggle  is enabled");
//				}
//				else {
//					System.out.println("remember.me.toggle  is disabled");
//				}
//			break;
//			default :
//			
		boolean exists1 = driver.findElementByXPath(androidprop.getProperty("remember.me.toggle.off")).isEnabled();
		if(exists1 == true) {
			System.out.println("remember.me.toggle  is enabled");
		}
		else {
			System.out.println("remember.me.toggle  is disabled");
		}
		androidactions.takescreenshot(feature);
		break;
	//}
}
}

	@Then("^I should see remember me toggle button is enabled$")
	public void i_should_see_remember_me_toggle_button_is_enabled() throws Throwable {
		switch(platform){
		case "android": 
//			switch (deviceName) {
//			case "samsungS9":
//				
//				boolean exists = driver.findElementByXPath(androidprop.getProperty("samsungs9.remember.me.toggle.on")).isEnabled();
//				if(exists == true) {
//					System.out.println("remember.me.toggle  is enabled");
//				}
//				else {
//					System.out.println("remember.me.toggle  is disabled");
//				}
//			break;
//			default :
			boolean exists1 = driver.findElementByXPath(androidprop.getProperty("remember.me.toggle.on")).isEnabled();
		if(exists1 == true) {
			System.out.println("remember.me.toggle  is enabled");
		}
		else {
			System.out.println("remember.me.toggle  is disabled");
		}
		androidactions.takescreenshot(feature);
		break;
	//}
	}
}
	
	@Then("^I should see terms and privacy screen$")
	public void i_should_see_terms_and_privacy_screen() throws Throwable {
		switch(platform){
		case "android":
			boolean exists1 = driver.findElementByXPath(androidprop.getProperty("terms.and.privacy")).isDisplayed();
			if(exists1 == true) {
				driver.findElementByXPath(androidprop.getProperty("agree.and.continue")).click();
			}
			boolean exists2 = driver.findElementByXPath(androidprop.getProperty("tempo.notifications.title")).isDisplayed();
			if(exists2 == true) {
				System.out.println("tempopopup is already displayed");
			}
			androidactions.takescreenshot(feature);
			break;
	}

	}

	@Then("^I should see \"([^\"]*)\" in \"([^\"]*)\" field$")
	public void i_should_see_in_field(String value, String object) throws Throwable {
		switch (platform) {
		case "android":
			boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
			if (exists) {
				String actualtext = androiddriver.findElementByXPath(androidprop.getProperty(object)).getText();
				String expectedtext = dataprop.getProperty(value);
				if (expectedtext.equals(actualtext)) {
					System.out.println(actualtext + " is displayed in " + object);
				} else {
					System.out.println(actualtext + " is not displayed in " + object);
				}

			}
			break;
		}
	}
}
