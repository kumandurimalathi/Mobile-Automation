
package stepDefinitions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.concordion.api.AfterSuite;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

import com.aventstack.extentreports.gherkin.model.Feature;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.google.common.io.Files;
import org.openqa.selenium.By;
import org.testng.annotations.BeforeSuite;

import config.AndroidBaseClass;
import config.baseclass;
import config.iOSBaseClass;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import helpers.mobileactions;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import utils.emailconfigurationforreg;
import utils.emailconfigurationforresendreg;
import utils.genericutilities;


public class given extends baseclass {
	public String platform, deviceName, features;
	private Properties androidprop;
	AndroidBaseClass android = new AndroidBaseClass(androiddriver);
	iOSBaseClass ios = new iOSBaseClass(iosdriver);
	mobileactions androidactions;
	emailconfigurationforreg emailconfig;
	emailconfigurationforresendreg emailconfig1;
	genericutilities utils;
	@Before
	public void incrementMAil(Scenario scenario) throws IOException, Exception {
		utils = new genericutilities();

		String filename = scenario.getId().split(";")[0].toUpperCase();
		System.out.println(filename+"  "+scenario.getId());
		feature = filename;
		
		switch (filename) {
		case "accountsetup":
			utils.incrementEmail("emailaddress");
			Thread.sleep(1000);
			utils.incrementEmail("emailaddress.valid.11.precondition");
			Thread.sleep(1000);
			break;
		case "MADELYNE-MORE-MENU-EDIT-PROFILE-SOFTWARE-TEST-PROTOCOL-ANDROID":
			System.out.println(features);
			utils.incrementEmail("emailaddress");
			Thread.sleep(1000);
			break;
		case "MADELYNE-ONBOARDING–PERSONALINFORMATION-SOFTWARE-TEST-PROTOCOL":
//			System.out.println(filename);
			utils.incrementEmail("emailaddress");
			Thread.sleep(1000);
			break;
		case "MADELYNE USER AUTHENTICATION – SOFTWARE TEST PROTOCOL":
			utils.incrementEmail("newregistered.email");
			Thread.sleep(1000);
			utils.incrementEmail("unregistered.email");
			Thread.sleep(1000);
			break;
		default:
			System.out.println("no need to increment");
			break;
		}
	}
	


	public given() throws Exception {
		platform = "android";
		deviceName = "Pixel2Xl";
//		iosdriver = ios.launchApp();
		androiddriver = android.launchApp();
		FileInputStream reader = new FileInputStream(
				System.getProperty("user.dir") + "/src/main/testdata/android.properties");

		androidprop = new Properties();
		androidprop.load(reader);
		androidactions = new mobileactions(androiddriver);

	}
	@Given("^I launch the Madelyne application$")
	public void launching_application() throws Throwable {

		switch (platform) {
		case "android":
			try {
				boolean exists = androidactions.waitForVisibility(androidprop.getProperty("login.to.your.account"));
				if (exists) {
					System.out.println("Login Screen is Displayed");
					driver.findElementByXPath(androidprop.getProperty("back")).click();
//					ExtentHtmlReporter logger = new ExtentHtmlReporter("user/build/name/");
//					((Object) logger.config()).setAutoCreateRelativePathMedia(true);
					androidactions.takescreenshot(feature);

				}
			} catch (Exception e) {
				boolean exists1 = androidactions.waitForVisibility(androidprop.getProperty("welcome.to.tempotm"));
				if (exists1) {
					System.out.println("Welcome to tempo is Visible");
					androidactions.takescreenshot(feature);
				}

			}
		}
	}

	@Given("^I verify email$")
	public void verify_email() {
		String URL = null;
		try {
			FileReader file = new FileReader(System.getProperty("user.dir") + "/src/main/testdata/emailconfig.txt");


			String st;
			while ((st = new BufferedReader(file).readLine()) != null) {
				URL = st;
			}
			file.close();
			mobileactions.launchbrowser(URL);

			file.close();
		} catch (Exception e) {
			System.out.println("Error" + e);
		}

	}

	@Given("^I store previous link$")
	public void i_store_previous_link() throws FileNotFoundException, IOException {
		String URL = null;
		try {

			File file = new File(
					System.getProperty("user.dir")+"/src/main/testdata/emailconfig.txt");


			String st;
			while ((st = new BufferedReader(new FileReader(file)).readLine()) != null) {
				URL = st;
			}
			FileWriter fileWriter = new FileWriter(

					System.getProperty("user.dir")+"/src/main/testdata/storeemail.txt");

			fileWriter.write(URL);
			fileWriter.close();
		} catch (Exception e) {
			System.out.println("Error" + e);
		}

	}

	@SuppressWarnings("resource")
	@Given("^I verify previous email$")
	public void i_verify_previous_email() throws Throwable {
		String URL = null;

		try {

			File file = new File(
					System.getProperty("user.dir")+"/src/main/testdata/storeemail.txt");


			String st;
			while ((st = new BufferedReader(new FileReader(file)).readLine()) != null) {
				URL = st;
			}
			mobileactions.launchbrowser(URL);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Given("^I should connect to email for resend registration verification$")
	public void i_should_connect_to_email_for_resend_registration_verification() throws Throwable {
		emailconfig1 = new emailconfigurationforresendreg();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String verificationLink = emailconfig1.getUrlFromMail();
//		System.out.println("Given : "+verificationLink);
		FileWriter fw = new FileWriter(System.getProperty("user.dir") + "/src/main/testdata/emailconfig.txt");
		fw.write(verificationLink);
		fw.close();

	}

	@Given("^I should connect to email for registration verification$")
	public void i_should_connect_to_email_for_registration_verification() throws Throwable {
		emailconfig = new emailconfigurationforreg();

		androiddriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		String verificationLink = emailconfig.getUrlFromMail();
//		System.out.println("Given : "+verificationLink);
		FileWriter fw = new FileWriter(System.getProperty("user.dir")+"/src/main/testdata/emailconfig.txt");

		fw.write(verificationLink);
		fw.close();
	}

	@Given("^I wait for recording$")
	public void i_wait_for_recording() throws Throwable {
		Thread.sleep(3000);
	}

	@Given("^I see \"([^\"]*)\" screen$")
	public void i_see_screen(String object) throws Throwable {
		switch (platform) {
		case "android":
			boolean exists = androidactions.waitForVisibility(androidprop.getProperty(object));
			if (exists) {
				System.out.println(object + " is displayed");
			}
			androidactions.takescreenshot(feature);;
			break;
			
		}

		
	}

	@SuppressWarnings("deprecation")
	@Given("^I set deviceformat to 12 hour$")
	public void i_set_deviceformat_to_hour() throws Throwable {
		switch (platform) {
		case "android":
			switch (deviceName) {
			case "oneplus":

				androiddriver.startActivity(new Activity("com.android.settings", "com.android.settings.Settings"));
				androiddriver.findElementByXPath(androidprop.getProperty("oneplus.settings.search")).click();
				androiddriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);	
				androiddriver.findElementByXPath(androidprop.getProperty("oneplus.settings.searchbox"))
						.sendKeys("Use 24-hour format");
				androiddriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);	
				androiddriver.findElementByXPath(androidprop.getProperty("oneplus.settings.24hour")).click();
				boolean exists = androidactions.waitForVisibility(androidprop.getProperty("oneplus.settings.24hour.toggle"));
				if (exists) {
					
					String value1 = androiddriver
							.findElementByXPath(androidprop.getProperty("oneplus.settings.24hour.toggle"))

							.getAttribute("checked");
					System.out.println(value1);
					if (value1.equals("true")) {
						androiddriver.findElementByXPath(androidprop.getProperty("oneplus.settings.24hour.toggle")).click();
						System.out.println("Changed to 12 Hour Format");
					} else {
						System.out.println("Already in 12 Hour Format");
					}
				}
				break;
			case "Pixel2Xl":
				driver.startActivity(new Activity("com.android.settings", "com.android.settings.Settings"));
				driver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.search")).click();
				driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
				driver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.searchbox"))
						.sendKeys("Use 24-hour format");
				driver.findElementByXPath(androidprop.getProperty("settings.24hour")).click();
				boolean exists1 = androidactions.waitForVisibility(androidprop.getProperty("settings.24hour"));
				if (exists1) {
					String autoToggle = driver
							.findElementByXPath(androidprop.getProperty("pixel2xl.settings.auto.toggle"))
							.getAttribute("checked");
					if (autoToggle.equals("false")) {
						System.out.println("Automatic 24-hour format already disabled");
					} else {
						driver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.auto.toggle")).click();
						System.out.println("Automatic 24-hour format disabled");
					}
					String value1 = driver
							.findElementByXPath(androidprop.getProperty("pixel2xl.settings.24hour.toggle"))
							.getAttribute("checked");
					if (value1.equals("true")) {
						driver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.24hour.toggle")).click();
						System.out.println("Changed to 12 Hour Format");
					} else {
						System.out.println("Already in 12 Hour Format");
					}
				}
				break;
			}
			while (!driver.getCurrentPackage().equals("com.lilly.ddcs.madelyne")) {
				driver.pressKey(new KeyEvent(AndroidKey.BACK));
			}
			androidactions.takescreenshot(feature);;

			break;

		}
		
	}
	@SuppressWarnings("deprecation")
	@Given("^I set deviceformat to 24 hour$")
	public void i_set_deviceformat_to_24hour() throws Throwable {
		switch (platform) {
		case "android":
			switch (deviceName) {
			
			case "Pixel2Xl":
				androiddriver.startActivity(new Activity("com.android.settings", "com.android.settings.Settings"));
				androiddriver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.search")).click();
				androiddriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);	
				androiddriver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.searchbox")).sendKeys("Use 24-hour format");
				androiddriver.findElementByXPath(androidprop.getProperty("settings.24hour")).click();
	            boolean exists1 = androidactions.waitForVisibility(androidprop.getProperty("settings.24hour"));
	            if (exists1) {
	              String autoToggle = androiddriver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.auto.toggle")).getAttribute("checked");
	              if (autoToggle.equals("false")) {
	                System.out.println("Automatic 24-hour format already disabled");
	              }
	              else {
	            	  androiddriver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.auto.toggle")).click();
	                System.out.println("Automatic 24-hour format disabled");
	              }
	              String value1 = androiddriver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.24hour.toggle")).getAttribute("checked");
	              if (value1.equals("false")) {
	            	  androiddriver.findElementByXPath(androidprop.getProperty("pixel2xl.settings.24hour.toggle")).click();
	            	  System.out.println("Changed to 24 Hour Format");
	              }
	              else {
	            	  System.out.println("Already in 24 Hour Format");
	              }
	            }
	            break;
			}
			while (!androiddriver.getCurrentPackage().equals("com.lilly.ddcs.madelyne")) {
				androiddriver.pressKeyCode(4);
		        }
			break;
			
		}
	}
	@After
	public void incremensfstMAil() throws IOException, InterruptedException {
//		utils = new genericutilities();
//		utils.incrementEmail("emailaddress");
		System.out.println("at after");
	}

	@Given("^I set device time as \"([^\"]*)\"$")
	public void i_set_device_time_as(String object) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}
//
//	@AfterStep
//	public void afterScenario(Scenario scenario) throws IOException {
//		if (scenario.isFailed()) {
////			System.out.println(scenario.getId());
////			System.out.println(scenario.getStatus());
////			System.out.println(scenario.getSourceTagNames());
////			System.out.println(scenario.getClass());
////			System.out.println(scenario.getName());
//			String screenshotName = scenario.getName().replaceAll(" ", "_");
////			System.out.println("here "+screenshotName);
////			 This takes a screenshot from the driver at save it to the specified location
//				File sourcePath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//
//				// Building up the destination path for the screenshot to save
//				// Also make sure to create a folder 'screenshots' with in the cucumber-report
//				// folder
//				File destinationPath = new File(System.getProperty("user.dir") + "/target/cucumber-reports/screenshots/"
//						+ screenshotName + ".png");
//
//				// Copy taken screenshot from source location to destination location
//				Files.copy(sourcePath, destinationPath);
//
//				// This attach the specified screenshot to the test
//				Reporter.addScreenCaptureFromPath(destinationPath.toString());
////			byte[] srcBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
////			 scenario.embed(srcBytes, "image/png");
//		}
////	}
//
//	}	
}

