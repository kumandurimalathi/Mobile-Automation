package runner;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.vimalselvam.cucumber.listener.ExtentProperties;
import com.vimalselvam.cucumber.listener.Reporter;

import config.baseclass;
import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.junit.Cucumber;
import helpers.mobileactions;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import utils.genericutilities;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "./features/accountsetup.feature" },
				     glue = { "stepDefinitions" },
//				   plugin = {"json:target/cucumber.json"}
plugin = {"com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:"}
			)

public class Runner{
	private static genericutilities utils;
	private static mobileactions androidactions;
	 @BeforeClass
	    public static void setup() {
	        ExtentProperties extentProperties = ExtentProperties.INSTANCE;
//	        extentProperties.setExtentXServerUrl("http://localhost:1337");
//	        extentProperties.setProjectName("MyProject");
	        extentProperties.setReportPath("output/myreport.html");
	    }
	@AfterClass
	public static void writeExtentReport() throws IOException, InterruptedException {
		Reporter.loadXMLConfig(new File(System.getProperty("user.dir")+"/extent-config.xml"));
		 Reporter.setSystemInfo("User Name", "Tempo");
	     Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
	     Reporter.setSystemInfo("Machine", "Mac OSX" + "64 Bit");
	     Reporter.setSystemInfo("Selenium", "3.7.0");
	     Reporter.setSystemInfo("Maven", "3.5.2");
	     Reporter.setSystemInfo("Java Version", "1.8.0_151");
	     SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy_hh_mm_ssaa");
			SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyyy");
			Date date = new Date();
			String fileName = sd.format(date);
			String filetime = sdf.format(date);
			File des = new File(System.getProperty("user.dir")+"/target/cucumber-reports/report.html");
			File destinationPath = new File(System.getProperty("user.dir")+"/target/cucumber-reports/reports/"+fileName+"/"+filetime+".html");
			FileUtils.copyFile(des,destinationPath);
			System.out.println("Report Generated At "+destinationPath);
	}
	
	
}
	