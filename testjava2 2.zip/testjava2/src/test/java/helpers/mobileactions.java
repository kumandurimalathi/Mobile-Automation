package helpers;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.google.common.io.Files;
import com.vimalselvam.cucumber.listener.Reporter;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import io.appium.java_client.AppiumDriver;
import config.baseclass;
import io.appium.java_client.LocksDevice;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.offset.PointOption;
import io.github.bonigarcia.wdm.WebDriverManager;

public class mobileactions extends baseclass{
	public static WebDriver webdriver;	
	public final int timeOut = 20;
	
	public mobileactions(IOSDriver<MobileElement> driver1) {
		this.iosdriver = driver1;
	}
	public mobileactions(AndroidDriver<MobileElement> driver1) {
		this.androiddriver = driver1;
	}
	public void swipeRight(double x) {
		Dimension size = androiddriver.manage().window().getSize();
		int startx = (int) (size.width * x);
		int endx = (int) (size.width * (1-x));
		int starty = size.height / 2;
		new TouchAction(androiddriver).press(PointOption.point(startx, starty))
				.moveTo(PointOption.point(endx, starty))
				.release().perform();
	}
//	public boolean waitForVisibility(String xpath) {
//       
//            WebDriverWait wait = new WebDriverWait(driver, timeOut);
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
//            return true;
//        
// 
//        
//    }
	
	public boolean waitForVisibility(String xpath) {
	       
        WebDriverWait wait = new WebDriverWait(androiddriver, timeOut);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        return true;
    

    
}
	public void swipeLeft(String xpath) {
		Dimension size = driver.manage().window().getSize();
		int startx = (int) (size.width * 0.8);
		int endx = (int) (size.width * 0.20);
       try {
            WebDriverWait wait = new WebDriverWait(androiddriver, timeOut);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
            
       }
       catch (Exception e) {
    	   System.out.println("Error : "+e);
    	  
       }
//	
 
        
    }
	public void swipeLeft(double x) {
		Dimension size = androiddriver.manage().window().getSize();
		int startx = (int) (size.width * x);
		int endx = (int) (size.width * (1-x));
		int starty = size.height / 2;
		new TouchAction(androiddriver).press(PointOption.point(startx, starty))
				.moveTo(PointOption.point(endx, starty))
				.release().perform();
	}

	public void swipeDown(double d) {
		Dimension size = androiddriver.manage().window().getSize();
//		System.out.println(size);
		int starty = (int) (size.height * d);
		int endy = (int) (size.height * (1-d));
		int startx = size.width / 2;
//		System.out.println(starty+"  "+endy+" "+startx);
		new TouchAction(androiddriver).longPress(PointOption.point(startx, starty))
				.moveTo(PointOption.point(startx, endy))
				.release().perform();
	}

	public void swipeUp(double x) {

		Dimension size = androiddriver.manage().window().getSize();
		int starty = (int) (size.height * x);
		int endy = (int) (size.height * (1-x));
		int startx = size.width / 2;
		new TouchAction(androiddriver).longPress(PointOption.point(startx, starty))
				.moveTo(PointOption.point(startx, endy))
				.release().perform();
	}

	public void scrollDownMultiple(int swipeTimes, int durationForSwipe) {
		Dimension dimension = androiddriver.manage().window().getSize();

		for (int i = 0; i <= swipeTimes; i++) {
			int start = (int) (dimension.getHeight() * 0.5);
			int end = (int) (dimension.getHeight() * 0.3);
			int x = (int) (dimension.getWidth() * .5);

			new TouchAction(androiddriver).press(PointOption.point(x, start)).moveTo(PointOption.point(x, end))
					.release().perform();
		}
	}

	public void swipeByCordinates(int x[], int y[]) {
		Dimension dimension = androiddriver.manage().window().getSize();

		new TouchAction(androiddriver).press(PointOption.point(x[0], x[1])).moveTo(PointOption.point(y[0], y[1])).release()
				.perform();
	}
	public void swipeByCordinates(int x,int y) {
		Dimension dimension = androiddriver.manage().window().getSize();

		new TouchAction(androiddriver).press(PointOption.point(x, y)).release()
				.perform();
	}
	public void tapOutsideElement() {
		Dimension dimension = androiddriver.manage().window().getSize();

		new TouchAction(androiddriver).press(PointOption.point(200,50)).release()
				.perform();
	}
	public boolean waitForInvisibility(By targetElement) {
		try {
			WebDriverWait wait = new WebDriverWait(androiddriver, timeOut);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(targetElement));
			return true;
		} catch (TimeoutException e) {
			System.out.println("Element is still visible: " + targetElement);
			System.out.println();
			System.out.println(e.getMessage());
			throw new TimeoutException();

		}
	}
	public void sendAppToBackground(int seconds) {
		androiddriver.runAppInBackground(Duration.ofSeconds(seconds));
	}
	public void screenLock() {
		((LocksDevice) androiddriver).lockDevice();
	}
	public void screenUnlock() {
		((LocksDevice) androiddriver).unlockDevice();
	}
	public void hideDeviceKeyboard() {
		androiddriver.hideKeyboard();
	}
	public void closeCurrentApp() {
		androiddriver.closeApp();
	}
	public static void launchbrowser(String URL) throws InterruptedException {
		
		System.out.println("URL");
////		WebDriverManager.chromedriver().setup();
//        WebDriver driver=new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		webdriver = new ChromeDriver();
		webdriver.get(URL);
		Thread.sleep(3000);
		webdriver.quit();
		
//		 WebDriverManager.chromedriver().setup();
//         WebDriver driver=new ChromeDriver();
//         driver.get(URL);
	}

	public void swipeTillText(String text) {
		androiddriver .findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+text+"\").instance(0))");

	}
	public void swipeDownTillElement(String xpath) {
		boolean flag = true;
		

		do {
			try {
				MobileElement element = androiddriver.findElementByXPath(xpath);
				if(element.isDisplayed()) {
					flag=false;
				}
			}
			catch(Exception e) {
				 			this.swipeDown(0.8);
			}
		}while(flag);
	}
	public boolean isEnabled(String property) {
		boolean value =androiddriver.findElementByXPath(property).isEnabled();
		return value;
		
	}
	
	public static boolean validateJavaDate(String strDate) {
		if (strDate.trim().equals(""))
		{
		    return true;
		}
		else
		{
		    SimpleDateFormat sdfrmt = new SimpleDateFormat("MM/dd/yyyy");
		    sdfrmt.setLenient(false);
		    try
		    {
		        Date javaDate = sdfrmt.parse(strDate); 
		        System.out.println(strDate+" is valid date format");
		    }
		   catch (ParseException e)
		    {
		        System.out.println(strDate+" is Invalid Date format");
		        return false;
		    }
		   return true;
		}
		
		
		
	   }	
	
	
	public void takescreenshot(String feature) throws IOException  {
			
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy_hh_mm_ssaa");
		SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		String foldername = sd.format(date);
		String fileName = sdf.format(date);
		File des = androiddriver.getScreenshotAs(OutputType.FILE);
		File destinationPath = new File(System.getProperty("user.dir")+"/target/cucumber-reports/screenshots/"+foldername+"/"+feature +"/"+fileName+".jpg");
		FileUtils.copyFile(des,destinationPath);
		Reporter.addScreenCaptureFromPath(destinationPath.toString());
//		ExtentReporter logger = new ExtentHtmlReporter("user/build/name/");
//		logger.config().setAutoCreateRelativePathMedia(true);
		}
//	public String get_feature_name(Scenario scenario) {
//		
//		String featureName = scenario.getId().split(";")[0];
//		 System.out.println(featureName);
//		 return featureName;
//		}
	
}
