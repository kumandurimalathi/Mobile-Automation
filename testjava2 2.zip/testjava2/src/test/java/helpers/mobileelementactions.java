package helpers;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
 
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
 
//import Methods1.Mrthods1;
 
public class mobileelementactions {   

	AndroidDriver<MobileElement> driver;
	public mobileelementactions(AndroidDriver<MobileElement> driver) {
		this.driver = driver;
	}
public void opennotifications(){
     driver.openNotifications();
}
 
public void launchApp() {
    driver.launchApp();
}
 
 
public void tap(double xPosition, double yPosition) {
    JavascriptExecutor js = (JavascriptExecutor) driver;
    HashMap<String, Double> tapObject = new HashMap<String, Double>();
    tapObject.put("startX", xPosition);
    tapObject.put("startY", yPosition);
    js.executeScript("mobile: tap", tapObject);
}
 
 
public MobileElement findElement(By locator) {
    try {
        MobileElement element = (MobileElement)driver.findElement(locator);
        return element;
    } catch (NoSuchElementException e) {
       
        throw new NoSuchElementException(e.getMessage());
    }
}
 
public String getDeviceTime() {
     String time = driver.getDeviceTime();
     return time;
}
 
public void selectPickerwheelValue(MobileElement element)
{
     JavascriptExecutor js = (JavascriptExecutor) driver;
     Map<String, Object> params = new HashMap<>();
     params.put("order", "next");
     params.put("offset", 0.15);
     params.put("element", ((RemoteWebElement) element).getId());
     js.executeScript("mobile: selectPickerWheelValue", params);
     System.out.println("Value Selected");
 
}
 
public void installApp() {
	JavascriptExecutor js = (JavascriptExecutor) driver;
     Map<String, Object> params = new HashMap<>();
     params.put("app", "http://example.com/myapp.ipa");
     js.executeScript("mobile: installApp", params);
     System.out.println("App Installed");
 
}
 
}