package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import config.baseclass;

public class genericutilities extends baseclass{
	private Properties dataprop;
	private Properties configprop;
	FileInputStream reader;
	public genericutilities() throws IOException {
		reader = new FileInputStream(
				System.getProperty("user.dir")+"/src/main/testdata/data.properties");
		dataprop = new Properties();
		dataprop.load(reader);
		FileInputStream Configreader = new FileInputStream(
				System.getProperty("user.dir")+"/src/main/testdata/Configurations.properties");
		configprop = new Properties();
		configprop.load(Configreader);
	}
	public void timestaamp() {
		Date date= new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		System.out.println("Current Time in TimeStamp "+ts);
		}
		
		public  String getDate( ) {
		     DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
		     Date date = new Date();
		     String date1= dateFormat.format(date);
		     System.out.println(date1);
			return date1;
		}
		 
		public String getDateandTime() {
		     DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		     Date date = new Date();
		     String date1= dateFormat.format(date);
		     System.out.println("Current date and time is " +date1);
			return date1;
		}
		 
		public String getCurrentYear() {
		    
		     Calendar now = Calendar.getInstance();
		     int year = now.get(Calendar.YEAR);
		    
		     String yearInString = String.valueOf(year);
		     System.out.println(yearInString);
			return yearInString;
		 
		}
		 
		 
		 
		public String getCurrentMonth () {
		    Calendar cal = Calendar.getInstance();
		    SimpleDateFormat month_date = new SimpleDateFormat("MMMMMM");
		 
		    return month_date.format(cal.getTime());
		}
		 
		 
		public String getCurrentTime24() {
		    
		         Calendar calendar = Calendar.getInstance();
		         SimpleDateFormat dateFormatter = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
		         return dateFormatter.format(calendar.getTime());
		     }
		 
		 
		 
		public String getCurrentTimeAmPm() {
		    
		    Calendar calendar = Calendar.getInstance();
		    SimpleDateFormat dateFormatter = new SimpleDateFormat("hh:mm:a", Locale.getDefault());
		    return dateFormatter.format(calendar.getTime());
		}
		 
		public int getPrevYear() {
		     Calendar prevYear = Calendar.getInstance();
		         prevYear.add(Calendar.YEAR, -1);
		         return prevYear.get(Calendar.YEAR);
		     }
		 
		public String getPrevMonth() {
		     Calendar cal =  Calendar.getInstance();
		     cal.add(Calendar.MONTH, -1);
		String previousMonthYear  = new SimpleDateFormat("MMM-yyyy").format(cal.getTime());
		return previousMonthYear;
		 
		 
		     }
		 
		public boolean isArraySorted(int[] array) {
		    for (int i = 0; i < array.length - 1; i++) {
		        if (array[i] > array[i + 1])
		            return false;
		    }
		    return true;
		}
		@SuppressWarnings("resource")
		public void incrementEmail(String object) throws IOException, InterruptedException {
//			System.out.println(object);
			String val = dataprop.getProperty(object);
//			System.out.println(val);
			String data1 = val.split("\\+")[1];
//			System.out.println(data1);
			long data = Long.parseLong(data1.split("@")[0].trim());
			String email[] = dataprop.getProperty("email").split("@");
			String value = email[0]+"+"+(data+1)+"@"+email[1];
//			System.out.println(value);
			reader.close();
			FileReader file = new FileReader(System.getProperty("user.dir")+"/src/main/testdata/data.properties");
			String s,totalfile="";
			
			    BufferedReader br = new BufferedReader(file);

			    while ((s = br.readLine()) != null) {
			    	if(s.contains(val)) {
//			    		System.out.println(s.replace(val, value));
			    		s=s.replace(val, value);
			    	}
			    	totalfile=totalfile+s+"\n";
			    	
			        // do something with the resulting line
			    }
			    totalfile.replace(val, value);
			file.close();
			FileWriter fileo  = new FileWriter(System.getProperty("user.dir")+"/src/main/testdata/data.properties");
			fileo.write(totalfile);
			fileo.close();
			Thread.sleep(5000);
		}
		
		public String getReportConfigPath(){
		 String reportConfigPath = configprop.getProperty("reportConfigPath");
		 System.out.println(reportConfigPath);
		 if(reportConfigPath!= null) return reportConfigPath;
		 else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath"); 
		}
		
		public void saveReport() throws IOException {
//			System.out.println(feature);
			 String filename = "Tempo";
//		     System.out.println(filename);
		     SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy_hh_mm_ssaa");
			Date date = new Date();
			String filetime = sdf.format(date);
			File des = new File(System.getProperty("user.dir")+"/target/cucumber-reports/report.html");
			File destinationPath = new File(System.getProperty("user.dir")+"/target/cucumber-reports/"+filename+"/"+filetime+".jpg");
			FileUtils.copyFile(des,destinationPath);
		
		}
		public static JSONArray getDeviceCapabilities() throws FileNotFoundException, IOException, org.json.simple.parser.ParseException {
			JSONParser jsonParser = new JSONParser();
			JSONObject cap = new JSONObject();;
			JSONArray capability = new JSONArray();
			JSONArray jsonarray = (JSONArray) jsonParser
					.parse(new FileReader(System.getProperty("user.dir") + "/src/main/testdata/caps.json"));
			try {
			Iterator<JSONObject> iterator = jsonarray.iterator();
			while (iterator.hasNext()) {
				cap = iterator.next();
				
				if ((boolean) cap.get("RunMode")) {
					
					capability.add(cap) ;
				}
			}
			}
			catch(Exception e) {
				System.out.println(e);
			}
			return capability;
		}
}
