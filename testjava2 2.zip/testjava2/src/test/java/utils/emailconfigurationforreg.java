package utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class emailconfigurationforreg {
	Folder inbox = null;
	Store store = null;

	public String getUrlFromMail() throws IOException, Exception {
		String string = "";
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");

		Session session = Session.getDefaultInstance(props, null);
		store = session.getStore("imaps");

		store.connect("imap.gmail.com", "lntelililly3@gmail.com", "Admins@123");

		inbox = store.getFolder("Inbox");
		inbox.open(Folder.READ_WRITE);
		Message[] messages = inbox.search(new FlagTerm(new Flags(Flags.Flag.SEEN), false));
		try {
		for (Message message : messages) {
			if (message.getSubject().contains("Madelyne email verification")) {

				string = saveUrl(getTextFromMimeMultipart((MimeMultipart) message.getContent()));

				System.out.println("-----Done-----");
			}
			// message.setFlag(Flags.Flag.SEEN, true);
		}
		}
		catch(Exception e) {
			System.out.println("ereror : "+e);
		}
		Thread.sleep(3000);
		System.out.println(string);
//		try {
//			FileWriter fw = new FileWriter("/Users/sureshvpatil/eclipse-workspace/lillyAutomation/src/main/testdata/emailconfig.txt");
//			fw.write(string);
//			fw.close();
//		} catch (Exception e) {
//			System.out.println(e);
//		}
		System.out.println("Success...");
		return string;
	}

	private static String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws Exception {
		String result = "";
		int partCount = mimeMultipart.getCount();
		for (int i = 0; i < partCount; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent(); 
				result = html;
			} else if (bodyPart.getContent() instanceof MimeMultipart) {
				result = result + getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
			}
		}
		return result;
	}

	public static String saveUrl(String body) throws MessagingException, IOException {

		String URL = "";
		Pattern p = Pattern.compile(
				"(^http|https)((([A-Za-z0-9$_.+!*(),;\\/?:@&~=-])|%[A-Fa-f0-9]{2}){2,}(#([a-zA-Z0-9][a-zA-Z0-9$_.+!*(),;\\/?:@&~=%-]*))?([A-Za-z0-9$_+!*();\\/?:~-]))",
				Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(body);
		if (m.find()) {
			System.out.println(m.group(0));
			URL = m.group(0);
		}
		return URL;

	}

	public static void saveParts(Object content, String filename) throws IOException, MessagingException {
		OutputStream out = null;
		InputStream in = null;
		try {
			if (content instanceof Multipart) {
				Multipart multi = ((Multipart) content);
				int parts = multi.getCount();
				for (int j = 0; j < parts; ++j) {
					MimeBodyPart part = (MimeBodyPart) multi.getBodyPart(j);
					if (part.getContent() instanceof Multipart) {
						// part-within-a-part, do some recursion...
						saveParts(part.getContent(), filename);
					} else {
						String extension = "";
						if (part.isMimeType("text/html")) {
							extension = "html";
						} else {
							if (part.isMimeType("text/plain")) {
								extension = "txt";
							} else {
								// Try to get the name of the attachment
								extension = part.getDataHandler().getName();
							}
							filename = filename + "." + extension;
							System.out.println("... " + filename);
							out = new FileOutputStream(new File(filename));
							in = part.getInputStream();
							int k;
							while ((k = in.read()) != -1) {
								out.write(k);
							}
						}
					}
				}
			}
		} finally {
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.flush();
				out.close();
			}
		}
	}

}