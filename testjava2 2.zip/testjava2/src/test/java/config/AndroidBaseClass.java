package config;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.FileNotFoundException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;


import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import utils.genericutilities;

public class AndroidBaseClass  {
	DesiredCapabilities capabilities = new DesiredCapabilities();
	AndroidDriver<MobileElement> AndroidDriver;
	genericutilities utils;
	public AndroidBaseClass(AndroidDriver<MobileElement> driver) throws IOException {
		this.AndroidDriver=driver;
		utils = new genericutilities();
		
	}


	public AndroidDriver<MobileElement> launchApp() throws FileNotFoundException, IOException, ParseException {
		JSONArray capa = genericutilities.getDeviceCapabilities();
		JSONObject caps = (JSONObject) (capa.iterator().next());
		capabilities.setCapability("deviceName", caps.get("deviceName"));
		capabilities.setCapability("platformName", caps.get("platformName"));
		capabilities.setCapability("platformVersion", caps.get("platformVersion"));
		capabilities.setCapability("automationName", caps.get("automationName"));
		capabilities.setCapability("udid", caps.get("udid"));
		capabilities.setCapability("autoGrantPermissions",caps.get("autoGrantPermissions"));
		capabilities.setCapability("app", System.getProperty("user.dir")+caps.get("app"));

		AndroidDriver= new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4725/wd/hub"), capabilities);

		
		return AndroidDriver;
	}
	public AndroidDriver<MobileElement> callDriver() {
		return AndroidDriver;
	}

}
