package config;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;

import cucumber.api.Scenario;

import cucumber.api.java.Before;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import utils.genericutilities;

public class baseclass {
	protected static AndroidDriver<MobileElement> driver;
	public static String feature;
	
	protected static IOSDriver<MobileElement> iosdriver;
	protected static AndroidDriver<MobileElement> androiddriver;
//	@BeforeAll
//	public void incrementsqwMAil() throws IOException, InterruptedException {
////		utils = new genericutilities();
////		utils.incrementEmail("emailaddress");
//		System.out.println("at before");
//	}
//	@AfterAll
//	public void incremfhentMAil() throws IOException, InterruptedException {
////		utils = new genericutilities();
////		utils.incrementEmail("emailaddress");
//		System.out.println("at after");
//	}

}

