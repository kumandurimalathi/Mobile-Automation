package config;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class iOSBaseClass {
	DesiredCapabilities capabilities = new DesiredCapabilities();
	IOSDriver<MobileElement> IOSDriver;
	public iOSBaseClass(IOSDriver<MobileElement> driver) {
		this.IOSDriver=driver;
		
		
	}
	public IOSDriver<MobileElement> launchApp() throws MalformedURLException {
	
		capabilities.setCapability("deviceName", "XSMax");
		capabilities.setCapability("platformName", "iOS");
		capabilities.setCapability("udid", "00008020-000641523698002E");
		capabilities.setCapability("autoGrantPermissions", true);
		capabilities.setCapability("bundleId", "com.lnt.madelyne");
		capabilities.setCapability("noReset", true);
		capabilities.setCapability("automationName", "XCUITest");
		IOSDriver= new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4726/wd/hub"), capabilities);
		
		return IOSDriver;
	}
	public IOSDriver<MobileElement> callDriver() {
		return IOSDriver;
	}
	
}
