
public class fileoperations {
	public jsonValue() { 
        JSONParser parser = new JSONParser();
 
        try {
 
            Object obj = parser.parse(new FileReader(System.getProperty("user.dir")+"/src/main/resources/testdata/mobilecaps.json"));
 
            JSONObject jsonObject = (JSONObject) obj;
 
            String name = (String) jsonObject.get("Name");
            String author = (String) jsonObject.get("Author");
 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
